#include "binshstr.h"

const char __binsh [] = "/bin/sh";

/* end of binshstr.c */
