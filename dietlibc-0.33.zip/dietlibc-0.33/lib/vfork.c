#include <unistd.h>

pid_t vfork() { return fork(); }

